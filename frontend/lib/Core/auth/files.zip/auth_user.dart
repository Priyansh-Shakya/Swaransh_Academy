import 'package:supabase_flutter/supabase_flutter.dart';
import 'user_role.dart';

/// Combines the Supabase identity (User) with the app-level role resolved
/// by the backend (POST /user). Kept separate from Supabase's own User type
/// so the rest of the app never imports supabase_flutter directly - only
/// this file and auth_notifier.dart need to.
class AuthUser {
  const AuthUser({
    required this.supabaseUser,
    required this.role,
    this.displayName,
    this.avatarUrl,
  });

  final User supabaseUser;
  final UserRole role;
  final String? displayName;
  final String? avatarUrl;

  String get id => supabaseUser.id;
  String get email => supabaseUser.email ?? '';

  static const AuthUser guest = _GuestAuthUser();
}

/// Sentinel for unauthenticated state - avoids nullable AuthUser? everywhere.
class _GuestAuthUser extends AuthUser {
  const _GuestAuthUser()
      : super(
          supabaseUser: const _FakeUser(),
          role: UserRole.guest,
        );

  @override
  String get id => '';
  @override
  String get email => '';
}

/// Minimal fake to satisfy the non-nullable field when role is guest.
class _FakeUser implements User {
  const _FakeUser();

  @override
  String get id => '';
  @override
  String? get email => null;
  @override
  dynamic noSuchMethod(Invocation invocation) => null;
}
