import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../Core/theme/app_colors.dart';
import '../../../Core/theme/app_spacing.dart';
import '../../../Core/theme/app_typography.dart';

class AdmissionTermsScreen extends ConsumerStatefulWidget {
  const AdmissionTermsScreen({super.key});

  @override
  ConsumerState<AdmissionTermsScreen> createState() =>
      _AdmissionTermsScreenState();
}

class _AdmissionTermsScreenState extends ConsumerState<AdmissionTermsScreen> {
  bool _accepted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.ivory,
      appBar: AppBar(
        title: const Text('Terms & Conditions'),
        backgroundColor: AppColors.ivory,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: _StepIndicator(current: 2, total: 3),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Please read carefully',
                      style: AppTypography.headlineLarge),
                  const SizedBox(height: 4),
                  Text(
                    'By proceeding to payment you agree to all terms below.',
                    style: AppTypography.bodySmall,
                  ),
                  const SizedBox(height: AppSpacing.xl),
                  ..._terms.map((t) => _TermsClause(
                        number: t.$1,
                        title: t.$2,
                        body: t.$3,
                      )),
                  const SizedBox(height: AppSpacing.lg),
                ],
              ),
            ),
          ),
          // Fixed bottom bar: checkbox + button
          Container(
            padding: const EdgeInsets.all(AppSpacing.lg),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: AppColors.divider)),
              boxShadow: [
                BoxShadow(
                  color: AppColors.navy.withOpacity(0.06),
                  blurRadius: 12,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Checkbox(
                      value: _accepted,
                      activeColor: AppColors.gold,
                      onChanged: (v) => setState(() => _accepted = v ?? false),
                    ),
                    Expanded(
                      child: Text(
                        'I have read and agree to the Terms & Conditions of '
                        'Swaransh Academy of Music & Art.',
                        style: AppTypography.bodySmall,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.sm),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _accepted
                        ? () => context.push('/admission/payment')
                        : null,
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: AppSpacing.xs),
                      child: Text('Continue to Payment'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TermsClause extends StatelessWidget {
  const _TermsClause(
      {required this.number, required this.title, required this.body});
  final int number;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.lg),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: AppColors.gold.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '$number',
                style: AppTypography.caption.copyWith(
                  color: AppColors.gold,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: AppTypography.bodyMedium
                        .copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(body, style: AppTypography.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StepIndicator extends StatelessWidget {
  const _StepIndicator({required this.current, required this.total});
  final int current;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.sm),
      child: Row(
        children: List.generate(total, (i) {
          final active = i < current;
          return Expanded(
            child: Container(
              margin: EdgeInsets.only(right: i < total - 1 ? 4 : 0),
              height: 3,
              decoration: BoxDecoration(
                color: active ? AppColors.gold : AppColors.divider,
                borderRadius: BorderRadius.circular(AppRadius.pill),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// ---- Terms content - edit here ----
// Tuple: (clause number, title, body text)
const _terms = [
  (
    1,
    'Fee Payment',
    'Fees are due as per the selected payment cycle (Monthly/Quarterly/Half-Yearly/Yearly). '
        'A grace period of 7 days is provided after the due date. Continued non-payment may result '
        'in suspension of classes.',
  ),
  (
    2,
    'Attendance',
    'Students are expected to maintain a minimum of 75% attendance. Irregular attendance '
        'without prior intimation may result in removal from the batch.',
  ),
  (
    3,
    'Conduct',
    'Students must maintain respectful conduct towards faculty, staff, and fellow students. '
        'Any form of misconduct may result in immediate termination of admission.',
  ),
  (
    4,
    'Refund Policy',
    'Fees once paid are non-refundable. In exceptional circumstances, requests may be '
        'considered by the management on a case-by-case basis.',
  ),
  (
    5,
    'Change of Course',
    'Course or batch changes are subject to availability and require prior approval from '
        'the academy management. A nominal administrative fee may apply.',
  ),
  (
    6,
    'Media & Photography',
    'The academy may photograph or record performances and classes for promotional purposes. '
        'Students who object must notify the management in writing at the time of admission.',
  ),
];
